G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-03-07T19:20:38+02:00*
G04 #@! TF.ProjectId,inkdaq,696e6b64-6171-42e6-9b69-6361645f7063,2.3*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-03-07 19:20:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.150000X-0.350000X-0.350000X0.350000X-0.350000X0.350000X0.350000X-0.350000X0.350000X0*%
%ADD11RoundRect,0.100000X-0.130000X-0.100000X0.130000X-0.100000X0.130000X0.100000X-0.130000X0.100000X0*%
%ADD12R,0.250000X0.450000*%
%ADD13RoundRect,0.150000X-0.150000X-0.150000X0.150000X-0.150000X0.150000X0.150000X-0.150000X0.150000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X176800000Y-128950000D03*
G04 #@! TD*
G04 #@! TO.C,J1*
X180750000Y-129250000D03*
G04 #@! TD*
G04 #@! TO.C,J3*
X178000000Y-130250000D03*
G04 #@! TD*
G04 #@! TO.C,J4*
X179450000Y-130350000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,C1*
X178810000Y-126700000D03*
X179450000Y-126700000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,B1*
X179450000Y-127600000D03*
X178250000Y-127600000D03*
X178250000Y-129000000D03*
X179450000Y-129000000D03*
D13*
X178850000Y-128300000D03*
G04 #@! TD*
M02*
